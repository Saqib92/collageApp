var globalData = /** @class */ (function () {
    function globalData() {
    }
    globalData.serviceUrl = "http://202.142.180.149:90/yourautoapp/api/";
    globalData.imagesUrl = "http://202.142.180.149:90/yourautoapp/public/images/";
    return globalData;
}());
export { globalData };
//# sourceMappingURL=helper.js.map