export class globalData{
	public static serviceUrl = "http://college.ummercial.com//api/v1/";
	public static imagesUrl = "";

}