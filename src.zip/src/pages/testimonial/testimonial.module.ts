import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TestimonialPage } from './testimonial';

@NgModule({
  declarations: [
    TestimonialPage,
  ],
  imports: [
    IonicPageModule.forChild(TestimonialPage),
  ],
})
export class TestimonialPageModule {}
