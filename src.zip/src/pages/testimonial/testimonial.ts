import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { HobbiesPage } from '../hobbies/hobbies';
import { DashboardPage } from '../dashboard/dashboard';
import { VideoPage } from '../video/video';
import { OptionsPage } from '../options/options';
/**
 * Generated class for the TestimonialPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-testimonial',
  templateUrl: 'testimonial.html',
})
export class TestimonialPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad TestimonialPage');
  }

  tohobbies() {
  	this.navCtrl.setRoot(HobbiesPage)
  }
  toProfile() {
  	this.navCtrl.setRoot(DashboardPage)
  }
  toVideo() {
  	this.navCtrl.setRoot(VideoPage);
  }
  tooption() {
  	this.navCtrl.setRoot(OptionsPage)
  }

}
