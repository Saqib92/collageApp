import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { UploadvideoPage } from './uploadvideo';

@NgModule({
  declarations: [
    UploadvideoPage,
  ],
  imports: [
    IonicPageModule.forChild(UploadvideoPage),
  ],
})
export class UploadvideoPageModule {}
